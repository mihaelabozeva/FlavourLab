# FlavorLab

## Overview

FlavorLab is a Django web application for exploring ingredients, flavour notes, flavour pairings, and cooking experiments. It helps users organise flavour information, discover ingredient combinations, and record the results of cooking experiments.

## Features

- Browse, search, filter, and sort ingredients.
- View ingredient details, including flavour notes and intensity.
- Create, edit, and delete ingredients.
- Create and manage flavour notes.
- Create flavour pairings and explain why ingredients complement each other.
- Record cooking experiments, including ingredients, observations, and results.
- Manage ingredients, pairings, and experiments through web forms.
- View readable ingredient intensity labels and a custom 404 page.

## Technologies

- Python
- Django
- HTML and CSS
- Database configured in Django settings (PostgreSQL)

## Configuration

The project runs with **SQLite and no configuration** by default. Optionally copy `.env.example` to `.env` to change settings:

| Variable | Default | Purpose |
|---|---|---|
| `SECRET_KEY` | insecure dev key | Django secret key |
| `DEBUG` | `True` | Set `False` to see the custom 404 page (run with `python manage.py runserver --insecure`) |
| `ALLOWED_HOSTS` | `localhost,127.0.0.1` | Comma-separated hosts |
| `DB_NAME`, `DB_USER`, `DB_PASS`, `DB_HOST`, `DB_PORT` | empty | Set `DB_NAME` to use PostgreSQL instead of SQLite |

No fixtures or prepopulated data are needed. Create ingredients first, then flavour notes, pairings and experiments through the site.
## Main Django apps

- **ingredients** — ingredients, flavour notes, and ingredient filtering.
- **pairings** — ingredient combinations and explanations.
- **experiments** — cooking experiments, observations, and results.

## Setup

1. Clone the repository:

   `git clone https://github.com/mihaelabozeva/FlavourLab.git`

2. Navigate into the project directory:

   `cd FlavourLab`

3. Create and activate a Python virtual environment.

4. Install the dependencies:

   `pip install -r requirements.txt`

5. Configure the environment variables required by your local settings. Do not commit secret values to version control.

6. Apply database migrations:

   `python manage.py migrate`

7. Start the development server:

   `python manage.py runserver`

8. Open `http://127.0.0.1:8000/` in your browser.

## Project status

FlavorLab was developed as a Django learning project, with a focus on managing related data, implementing CRUD operations, validating forms, and using reusable templates.
